//
//  FirestoreReferenceManager.swift
//  SwifyToken
//
//  Created by Meghana on 15/04/20.
//  Copyright © 2020 Meghana. All rights reserved.
//

import Foundation
import Firebase

struct FirestoreReferenceManager {
    
    static let environment = "dev"
    
    static let db = Firestore.firestore()
    static let root = db.collection(environment).document(environment)
    
    static func referenceForUserPublicData(uid: String) -> DocumentReference {
        return root
            .collection(FirebaseKeys.CollectionPath.users)
            .document(uid)
            .collection(FirebaseKeys.CollectionPath.publicData)
            .document(FirebaseKeys.CollectionPath.publicData)
    }
}
